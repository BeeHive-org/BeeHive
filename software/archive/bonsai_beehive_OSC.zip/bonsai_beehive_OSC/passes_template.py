wifiPass = "wifipassword_here"
wifiID = "wifi network name"
